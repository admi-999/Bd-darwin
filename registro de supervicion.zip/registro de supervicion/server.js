require('dotenv').config(); // 1. Cargar variables de entorno
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const path = require('path');
const jwt = require('jsonwebtoken'); // 2. Importar JWT
const bcrypt = require('bcryptjs'); // 3. Importar Bcrypt


const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Configuración de conexión usando variables de entorno
const db = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASS, 
    database: process.env.DB_NAME
});

db.connect(err => {
    if (err) {
        console.error('❌ ERROR: No se pudo conectar a MySQL:', err.sqlMessage);
        return;
    }
    console.log('✅ Conectado a la base de datos segura');
});

// --- MIDDLEWARE DE AUTENTICACIÓN (JWT) ---
// Esta función protege tus rutas para que solo usuarios con token puedan entrar
const verificarToken = (req, res, next) => {
    const token = req.headers['authorization'];
    if (!token) return res.status(403).json({ error: "No se proporcionó un token" });

    jwt.verify(token.split(" ")[1], process.env.JWT_SECRET, (err, decoded) => {
        if (err) return res.status(401).json({ error: "Token inválido o expirado" });
        req.usuarioId = decoded.id;
        next();
    });
};

// --- RUTA DE LOGIN (Ejemplo rápido) ---
app.post('/api/auth/login', (req, res) => {
    const { usuario, password } = req.body;
    console.log("Intentando login para:", usuario); // Ver esto en la consola de Node

    // 1. Buscamos el usuario en la tabla
    const sql = "SELECT * FROM usuarios WHERE username = ?";
    db.query(sql, [usuario], (err, results) => {
        if (err) return res.status(500).json({ error: "Error en el servidor" });
        
        // 2. ¿Existe el usuario?
        if (results.length === 0) {
            return res.status(401).json({ error: "Usuario no encontrado" });
        }

        const user = results[0];

        // 3. Comparar contraseña encriptada
        const passwordCorrecta = bcrypt.compareSync(password, user.password);
        
        if (!passwordCorrecta) {
            return res.status(401).json({ error: "Contraseña incorrecta" });
        }

        // 4. Generar Token si todo es correcto
        const token = jwt.sign(
            { id: user.id, username: user.username, rol: user.rol }, 
            process.env.JWT_SECRET, 
            { expiresIn: '8h' }
        );

        res.json({ 
            message: "Bienvenido " + (user.nombre_completo || user.username), 
            token 
        });
    });
});

// --- OPERACIONES CRUD (Ahora protegidas con verificarToken) ---

// 1. LEER (GET) - Protegida
app.get('/api/:tabla', verificarToken, (req, res) => {
    const tabla = req.params.tabla;
    const tablasPermitidas = ['accion', 'accion_especifica', 'actividad', 'detalle_registro', 'subaccion', 'tipo_agente', 'tipo_transporte', 'zona_distrito', 'zona_provincia'];
    
    if (!tablasPermitidas.includes(tabla)) return res.status(400).json({ error: "Tabla no válida" });

    // Si la tabla es detalle_registro, hacemos el JOIN para traer nombres en lugar de IDs
    if (tabla === 'detalle_registro') {
        const sql = `
            SELECT 
                r.*, 
                a.NOMBRE_ACCION, 
                ae.ACCION_ESPECIFICA, 
                p.NOMBRE_PROVINCIA,
                t.NOMBRE_TRANSPORTE
            FROM detalle_registro r
            LEFT JOIN accion a ON r.ID_ACCION = a.ID_ACCION
            LEFT JOIN accion_especifica ae ON r.ID_AE = ae.ID_AE
            LEFT JOIN zona_provincia p ON r.ID_ZP = p.id_zp
            LEFT JOIN tipo_transporte t ON r.ID_TT = t.id_tt
        `;
        db.query(sql, (err, data) => {
            if (err) return res.status(500).json({ error: err.sqlMessage });
            res.json(data);
        });
    } else {
        // Para las demás tablas, seguimos con el SELECT normal
        db.query(`SELECT * FROM ${tabla}`, (err, data) => {
            if (err) return res.status(500).json({ error: err.sqlMessage });
            res.json(data);
        });
    }
});

// 2. CREAR (POST) - Protegida y con Bcrypt ejemplo
app.post('/api/:tabla', verificarToken, (req, res) => {
    const tabla = req.params.tabla;
    let datos = req.body;
    const campoId = obtenerNombreId(tabla);

    if (campoId && datos[campoId]) delete datos[campoId];

    // Ejemplo: Si la tabla fuera de usuarios, encriptamos la clave
    if (tabla === 'usuarios' && datos.password) {
        const salt = bcrypt.genSaltSync(10);
        datos.password = bcrypt.hashSync(datos.password, salt);
    }

    db.query(`INSERT INTO ${tabla} SET ?`, datos, (err, result) => {
        if (err) return res.status(500).json({ error: err.sqlMessage });
        res.json({ message: "Insertado con éxito", id: result.insertId });
    });
});

// 3. ACTUALIZAR (PUT) - Protegida
app.put('/api/:tabla/:id', verificarToken, (req, res) => {
    const { tabla, id } = req.params;
    const datos = req.body;
    const campoId = obtenerNombreId(tabla);

    db.query(`UPDATE ${tabla} SET ? WHERE ${campoId} = ?`, [datos, id], (err, result) => {
        if (err) return res.status(500).json({ error: err.sqlMessage });
        res.json({ message: "Actualizado con éxito" });
    });
});

// 4. ELIMINAR (DELETE) - Protegida
app.delete('/api/:tabla/:id', verificarToken, (req, res) => {
    const { tabla, id } = req.params;
    const campoId = obtenerNombreId(tabla);

    db.query(`DELETE FROM ${tabla} WHERE ${campoId} = ?`, [id], (err, result) => {
        if (err) return res.status(500).json({ error: err.sqlMessage });
        res.json({ message: "Eliminado correctamente" });
    });
});

function obtenerNombreId(tabla) {
    const mapping = {
        'accion': 'ID_ACCION', 'accion_especifica': 'ID_AE', 'actividad': 'ID_ACTIVIDAD',
        'detalle_registro': 'ID_REGISTRO', 'subaccion': 'ID_SA', 'tipo_agente': 'ID_TA',
        'tipo_transporte': 'id_tt', 'zona_distrito': 'id_zd', 'zona_provincia': 'id_zp'
    };
    return mapping[tabla];
}

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log("------------------------------------------");
    console.log(`🚀 Servidor Darwin en http://localhost:${PORT}`);
    console.log("------------------------------------------");
});