const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Configuración de conexión
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '', 
    database: 'bd-darwinn' // Nombre exacto que verificamos
});

// Verificar conexión al iniciar
db.connect(err => {
    if (err) {
        console.error('❌ ERROR CRÍTICO: No se pudo conectar a MySQL:', err.sqlMessage);
        return;
    }
    console.log('✅ Conectado exitosamente a la base de datos: bd-darwinn');
});

// --- OPERACIONES CRUD GENÉRICAS ---

// 1. LEER (GET)
app.get('/api/:tabla', (req, res) => {
    const tabla = req.params.tabla;
    const tablasPermitidas = ['accion', 'accion_especifica', 'actividad', 'detalle_registro', 'subaccion', 'tipo_agente', 'tipo_transporte', 'zona_distrito', 'zona_provincia'];
    
    if (!tablasPermitidas.includes(tabla)) return res.status(400).json({ error: "Tabla no válida" });

    db.query(`SELECT * FROM ${tabla}`, (err, data) => {
        if (err) {
            console.error(`❌ Error al leer ${tabla}:`, err.sqlMessage);
            return res.status(500).json({ error: err.sqlMessage });
        }
        res.json(data);
    });
});

// 2. CREAR (POST)
app.post('/api/:tabla', (req, res) => {
    const tabla = req.params.tabla;
    const datos = req.body;
    const campoId = obtenerNombreId(tabla);

    // LIMPIEZA: Eliminamos el ID si viene en el body para evitar errores de autoincremento
    if (campoId && datos[campoId]) {
        delete datos[campoId];
    }

    db.query(`INSERT INTO ${tabla} SET ?`, datos, (err, result) => {
        if (err) {
            console.error(`❌ Error al insertar en ${tabla}:`, err.sqlMessage);
            return res.status(500).json({ error: "Error de servidor", detalle: err.sqlMessage });
        }
        res.json({ message: "Insertado con éxito", id: result.insertId });
    });
});

// 3. ACTUALIZAR (PUT)
app.put('/api/:tabla/:id', (req, res) => {
    const { tabla, id } = req.params;
    const datos = req.body;
    const campoId = obtenerNombreId(tabla);

    db.query(`UPDATE ${tabla} SET ? WHERE ${campoId} = ?`, [datos, id], (err, result) => {
        if (err) {
            console.error(`❌ Error al actualizar ${tabla}:`, err.sqlMessage);
            return res.status(500).json({ error: err.sqlMessage });
        }
        res.json({ message: "Actualizado con éxito" });
    });
});

// 4. ELIMINAR (DELETE)
app.delete('/api/:tabla/:id', (req, res) => {
    const { tabla, id } = req.params;
    const campoId = obtenerNombreId(tabla);

    db.query(`DELETE FROM ${tabla} WHERE ${campoId} = ?`, [id], (err, result) => {
        if (err) {
            console.error(`❌ Error al eliminar en ${tabla}:`, err.sqlMessage);
            return res.status(500).json({ error: err.sqlMessage });
        }
        res.json({ message: "Eliminado correctamente" });
    });
});

// Mapeo de IDs
function obtenerNombreId(tabla) {
    const mapping = {
        'accion': 'ID_ACCION',
        'accion_especifica': 'ID_AE',
        'actividad': 'ID_ACTIVIDAD',
        'detalle_registro': 'ID_REGISTRO',
        'subaccion': 'ID_SA',
        'tipo_agente': 'ID_TA',
        'tipo_transporte': 'id_tt',
        'zona_distrito': 'id_zd',
        'zona_provincia': 'id_zp'
    };
    return mapping[tabla];
}

app.listen(3000, () => {
    console.log("------------------------------------------");
    console.log("🚀 Servidor corriendo en http://localhost:3000");
    console.log("------------------------------------------");
});