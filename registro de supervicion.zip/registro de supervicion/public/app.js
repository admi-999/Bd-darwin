// 1. Configuración de los 9 CRUDs
const configuracion = {
    registro: {
        titulo: "Detalle de Registros",
        campos: ["id_accion", "id_ae", "id_sa", "id_ta", "id_tt", "id_zd", "id_zp", "id_actividad", "num_supervisores", "empresa_supervisora", "calidad_entregable", "nro_expediente", "carta_linea", "observaciones", "contrato"],
        columnas: ["ID", "Acción", "A.E.", "SubA", "Agente", "Transp", "Dist", "Prov", "Actividad", "Superv", "Empresa", "Calidad", "Exp", "Carta", "Obs", "Contrato"]
    },
    accion: {
        titulo: "Catálogo de Acciones",
        campos: ["nombre_abreviado", "nombre_accion", "codigo_a_e", "codigo_p_accion"],
        columnas: ["ID", "Abrev", "Nombre", "Cod AE", "Cod P"]
    },
    ae: {
        titulo: "Acciones Específicas",
        campos: ["nombre_abreviado", "accion_especifica", "codigo_a_e"],
        columnas: ["ID", "Abrev", "Acción Esp.", "Cod AE"]
    },
    actividad: {
        titulo: "Actividades",
        campos: ["nombre_actividad", "codigo_actividad", "id_ta"],
        columnas: ["ID", "Nombre", "Código", "ID Agente"]
    },
    subaccion: {
        titulo: "Sub-Acciones",
        campos: ["nombre_abreviado", "sub_accion_esp", "concat", "codigo_s_a_e", "id_ae"],
        columnas: ["ID", "Abrev", "SubAcción", "Concat", "Cod SAE", "ID AE"]
    },
    agente: {
        titulo: "Tipos de Agente",
        campos: ["nombre_ta"],
        columnas: ["ID", "Nombre Agente"]
    },
    transporte: {
        titulo: "Tipos de Transporte",
        campos: ["NOMBRE_TRANSPORTE"], 
        columnas: ["ID", "Transporte"]
    },
    provincia: {
        titulo: "Gestión de Provincias",
        campos: ["nombre_provincia"],
        columnas: ["ID", "Provincia"]
    },
    distrito: {
        titulo: "Gestión de Distritos",
        campos: ["nombre_distrito", "id_zp"],
        columnas: ["ID", "Distrito", "ID Prov"]
    }
};

let seccionActual = 'registro';
let editandoId = null;
let idParaEliminar = null; // Para el modal de borrado

// 2. Navegación entre secciones
function showSection(seccion) {
    seccionActual = seccion;
    limpiarForm(); 
    
    const config = configuracion[seccion];
    document.getElementById('titulo-crud').innerText = `Gestión de ${config.titulo}`;
    
    const formContainer = document.getElementById('form-dinamico');
    formContainer.innerHTML = config.campos.map(campo => `
        <div class="input-group">
            <label>${campo.replace(/_/g, ' ').toUpperCase()}</label>
            <input type="text" id="input-${campo}" placeholder="Ingrese ${campo}">
        </div>
    `).join('');

    const tableHead = document.getElementById('tabla-head');
    tableHead.innerHTML = `<tr>${config.columnas.map(col => `<th>${col}</th>`).join('')} <th>Acciones</th></tr>`;

    cargarDatosTabla(seccion);
}

// 3. Cargar datos (READ)
async function cargarDatosTabla(seccion) {
    try {
        const tablaApi = obtenerNombreTablaAPI(seccion);
        const response = await fetch(`/api/${tablaApi}`);
        const datos = await response.json();
        const tablaBody = document.getElementById('tabla-body');
        const config = configuracion[seccion];
        const campoId = obtenerNombreIdLocal(tablaApi);

        tablaBody.innerHTML = datos.map(fila => {
            const filaString = JSON.stringify(fila).replace(/"/g, '&quot;');
            const idActual = fila[campoId] || fila[campoId.toLowerCase()];

            return `
                <tr>
                    <td>${idActual}</td>
                    ${config.campos.map(campo => `<td>${fila[campo.toUpperCase()] || fila[campo] || ''}</td>`).join('')}
                    <td>
                        <div style="display: flex; gap: 5px;">
                            <button class="btn-save" style="padding:5px; box-shadow:none;" onclick="prepararEdicion(${idActual}, ${filaString})">✎</button>
                            <button class="btn-cancel" style="padding:5px; box-shadow:none;" onclick="confirmarEliminar(${idActual})">🗑</button>
                        </div>
                    </td>
                </tr>
            `;
        }).join('');
    } catch (error) {
        console.error("Error al cargar tabla:", error);
    }
}

// 4. Guardar o Actualizar (CREATE / UPDATE)
async function guardar() {
    const config = configuracion[seccionActual];
    const datos = {};
    const tablaApi = obtenerNombreTablaAPI(seccionActual);
    const campoId = obtenerNombreIdLocal(tablaApi);

    config.campos.forEach(campo => {
        const input = document.getElementById(`input-${campo}`);
        if (input) {
            datos[campo.toUpperCase()] = input.value;
        }
    });

    const url = editandoId ? `/api/${tablaApi}/${editandoId}` : `/api/${tablaApi}`;
    const metodo = editandoId ? 'PUT' : 'POST';

    try {
        const response = await fetch(url, {
            method: metodo,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(datos)
        });

        if (response.ok) {
            mostrarNotificacion(editandoId ? "¡Actualizado con éxito!" : "¡Guardado con éxito!");
            limpiarForm();
            cargarDatosTabla(seccionActual);
        } else {
            const errorServer = await response.json();
            mostrarNotificacion("Error: " + (errorServer.detalle || "Fallo en servidor"), "error");
        }
    } catch (error) {
        mostrarNotificacion("Error de conexión", "error");
    }
}

// 5. Preparar Edición
function prepararEdicion(id, datosFila) {
    editandoId = id;
    const config = configuracion[seccionActual];
    const btnSubmit = document.querySelector('button[onclick="guardar()"]');
    if(btnSubmit) btnSubmit.innerText = "Actualizar Registro";

    config.campos.forEach(campo => {
        const input = document.getElementById(`input-${campo}`);
        if(input) {
            input.value = datosFila[campo.toUpperCase()] || datosFila[campo] || '';
        }
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// 6. Eliminar con Modal Neumorfista
function confirmarEliminar(id) {
    idParaEliminar = id;
    const modal = document.getElementById('modal-confirmacion');
    if(modal) modal.style.display = 'flex';
    else if(confirm("¿Deseas eliminar este registro?")) ejecutarEliminar(); // Backup
}

function cerrarModal() {
    document.getElementById('modal-confirmacion').style.display = 'none';
    idParaEliminar = null;
}

async function ejecutarEliminar() {
    if (!idParaEliminar) return;
    const tablaApi = obtenerNombreTablaAPI(seccionActual);
    
    try {
        const response = await fetch(`/api/${tablaApi}/${idParaEliminar}`, { method: 'DELETE' });
        if(response.ok) {
            if(document.getElementById('modal-confirmacion')) cerrarModal();
            mostrarNotificacion("Eliminado correctamente");
            cargarDatosTabla(seccionActual);
        }
    } catch (error) {
        mostrarNotificacion("Error al eliminar", "error");
    }
}

// 7. Helpers
function obtenerNombreIdLocal(tabla) {
    const mapping = {
        'accion': 'ID_ACCION', 'accion_especifica': 'ID_AE', 'actividad': 'ID_ACTIVIDAD',
        'detalle_registro': 'ID_REGISTRO', 'subaccion': 'ID_SA', 'tipo_agente': 'ID_TA',
        'tipo_transporte': 'id_tt', 'zona_distrito': 'id_zd', 'zona_provincia': 'id_zp'
    };
    return mapping[tabla];
}

function obtenerNombreTablaAPI(seccion) {
    const map = {
        'registro': 'detalle_registro', 'ae': 'accion_especifica', 'agente': 'tipo_agente',
        'transporte': 'tipo_transporte', 'provincia': 'zona_provincia', 'distrito': 'zona_distrito'
    };
    return map[seccion] || seccion;
}

function limpiarForm() {
    editandoId = null;
    const btnSubmit = document.querySelector('button[onclick="guardar()"]');
    if(btnSubmit) btnSubmit.innerText = "Guardar Registro";
    const inputs = document.querySelectorAll('#form-dinamico input');
    inputs.forEach(i => i.value = "");
}

function mostrarNotificacion(mensaje, tipo = 'success') {
    const container = document.getElementById('toast-container');
    if(!container) return;
    const toast = document.createElement('div');
    toast.className = `toast ${tipo}`;
    toast.innerHTML = `<span>${mensaje}</span>`;
    container.appendChild(toast);
    setTimeout(() => {
        toast.style.animation = 'fadeOut 0.5s ease forwards';
        setTimeout(() => toast.remove(), 500);
    }, 3000);
}

// Inicializar
document.addEventListener('DOMContentLoaded', () => {
    showSection('registro');
    // Vincular botón del modal si existe
    const btnConfirm = document.getElementById('btn-confirmar-borrado');
    if(btnConfirm) btnConfirm.onclick = ejecutarEliminar;
});