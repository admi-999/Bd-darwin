// 1. Configuración de los 9 CRUDs
const configuracion = {
    registro: {
        titulo: "Detalle de Registros",
        campos: ["id_accion", "id_ae", "id_sa", "id_ta", "id_tt", "id_zd", "id_zp", "id_actividad", "num_supervisores", "empresa_supervisora", "calidad_entregable", "nro_expediente", "carta_linea", "observaciones", "contrato"],
        columnas: ["ID", "Acción", "A.E.", "SubA", "Agente", "Transp", "Dist", "Prov", "Actividad", "Superv", "Empresa", "Calidad", "Exp", "Carta", "Obs", "Contrato"]
    },
    accion: {
        titulo: "Catálogo de Acciones",
        campos: ["nombre_abreviado", "nombre_accion", "codigo_a_e", "codigo_p_accion"],
        columnas: ["ID", "Abrev", "Nombre", "Cod AE", "Cod P"]
    },
    ae: {
        titulo: "Acciones Específicas",
        campos: ["nombre_abreviado", "accion_especifica", "codigo_a_e"],
        columnas: ["ID", "Abrev", "Acción Esp.", "Cod AE"]
    },
    actividad: {
        titulo: "Actividades",
        campos: ["nombre_actividad", "codigo_actividad", "id_ta"],
        columnas: ["ID", "Nombre", "Código", "ID Agente"]
    },
    subaccion: {
        titulo: "Sub-Acciones",
        campos: ["nombre_abreviado", "sub_accion_esp", "concat", "codigo_s_a_e", "id_ae"],
        columnas: ["ID", "Abrev", "SubAcción", "Concat", "Cod SAE", "ID AE"]
    },
    agente: {
        titulo: "Tipos de Agente",
        campos: ["nombre_ta"],
        columnas: ["ID", "Nombre Agente"]
    },
    transporte: {
        titulo: "Tipos de Transporte",
        campos: ["NOMBRE_TRANSPORTE"], 
        columnas: ["ID", "Transporte"]
    },
    provincia: {
        titulo: "Gestión de Provincias",
        campos: ["nombre_provincia"],
        columnas: ["ID", "Provincia"]
    },
    distrito: {
        titulo: "Gestión de Distritos",
        campos: ["nombre_distrito", "id_zp"],
        columnas: ["ID", "Distrito", "ID Prov"]
    }
};

// Variables Globales
let seccionActual = 'registro';
let editandoId = null;
let idParaEliminar = null;
const API_URL = 'http://localhost:3000/api';

// --- LÓGICA DE AUTENTICACIÓN ---

async function iniciarSesion() {
    const usuario = document.getElementById('login-user').value;
    const password = document.getElementById('login-pass').value;

    try {
        const response = await fetch(`${API_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ usuario, password })
        });

        const data = await response.json();

        if (response.ok) {
            localStorage.setItem('darwin_token', data.token);
            document.getElementById('login-overlay').style.display = 'none';
            mostrarNotificacion("¡Bienvenido al Sistema Darwin!");
            showSection('registro');
        } else {
            mostrarNotificacion(data.error || "Credenciales inválidas", "error");
        }
    } catch (error) {
        mostrarNotificacion("Error de conexión con el servidor", "error");
    }
}

function cerrarSesion() {
    // 1. Eliminamos el token del almacenamiento local
    localStorage.removeItem('darwin_token');
    
    // 2. Mostramos una notificación rápida (opcional)
    mostrarNotificacion("Sesión cerrada correctamente", "success");

    // 3. Recargamos la página para forzar el bloqueo del sistema
    setTimeout(() => {
        location.reload();
    }, 500);
}

// --- NAVEGACIÓN Y RENDERIZADO ---

async function showSection(seccion) {
    const token = localStorage.getItem('darwin_token');
    if (!token) return;

    seccionActual = seccion;
    limpiarForm(); 

    // Resaltar menú activo
    document.querySelectorAll('.sidebar li').forEach(li => {
        li.classList.remove('active-menu');
        const onclickAttr = li.getAttribute('onclick');
        if(onclickAttr && onclickAttr.includes(seccion)) li.classList.add('active-menu');
    });

    const config = configuracion[seccion];
    document.getElementById('titulo-crud').innerHTML = `Gestión de <span class="accent-text">${config.titulo}</span>`;
    
    const formContainer = document.getElementById('form-dinamico');
    
    // --- NUEVO: Lógica de generación de inputs o selects ---
    let htmlForm = "";
    for (const campo of config.campos) {
        const label = campo.replace(/id_|ID_/g, '').replace(/_/g, ' ');
        
        // Si el campo empieza por "id_" y estamos en registro, creamos un SELECT
        if (seccion === 'registro' && campo.startsWith('id_')) {
            htmlForm += `
                <div class="input-group">
                    <label>${label}</label>
                    <select id="input-${campo}">
                        <option value="">Cargando...</option>
                    </select>
                </div>`;
        } else {
            // Campos normales (texto, observaciones, etc.)
            htmlForm += `
                <div class="input-group">
                    <label>${label}</label>
                    <input type="text" id="input-${campo}" placeholder="...">
                </div>`;
        }
    }
    formContainer.innerHTML = htmlForm;

    // Si es la sección de registro, llenamos los selects con datos de la API
    if (seccion === 'registro') {
        llenarSelectsDeRegistro();
    }

    const tableHead = document.getElementById('tabla-head');
    tableHead.innerHTML = `<tr>${config.columnas.map(col => `<th>${col}</th>`).join('')} <th>Acciones</th></tr>`;

    cargarDatosTabla(seccion);
}

// --- OPERACIONES CRUD (PROTEGIDAS) ---

async function cargarDatosTabla(seccion) {
    const token = localStorage.getItem('darwin_token');
    try {
        const tablaApi = obtenerNombreTablaAPI(seccion);
        const response = await fetch(`${API_URL}/${tablaApi}`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });

        if (response.status === 401 || response.status === 403) return cerrarSesion();

        const datos = await response.json();
        const tablaBody = document.getElementById('tabla-body');
        const config = configuracion[seccion];
        const campoId = obtenerNombreIdLocal(tablaApi);

        // MAPEO: Si el campo es un ID, buscamos si el servidor nos envió el NOMBRE real
        const mappingNombres = {
            'id_accion': 'NOMBRE_ACCION',
            'id_ae': 'ACCION_ESPECIFICA',
            'id_zp': 'NOMBRE_PROVINCIA',
            'id_tt': 'NOMBRE_TRANSPORTE',
            'id_sa': 'SUB_ACCION_ESP',
            'id_actividad': 'NOMBRE_ACTIVIDAD'
        };

        tablaBody.innerHTML = datos.map(fila => {
            const filaString = JSON.stringify(fila).replace(/"/g, '&quot;');
            const idActual = fila[campoId] || fila[campoId.toLowerCase()];

            // Generamos las celdas dinámicamente
            const celdas = config.campos.map(campo => {
                // 1. ¿Es un campo con nombre descriptivo (gracias al JOIN)?
                const nombreDescriptivo = mappingNombres[campo];
                
                // 2. Elegimos qué valor mostrar:
                // Prioridad: Nombre descriptivo > Campo en MAYÚSCULAS > Campo tal cual
                const valorMostrado = fila[nombreDescriptivo] || fila[campo.toUpperCase()] || fila[campo] || '';
                
                return `<td>${valorMostrado}</td>`;
            }).join('');

            return `
                <tr>
                    <td>${idActual}</td>
                    ${celdas}
                    <td>
                        <div style="display: flex; gap: 5px;">
                            <button class="btn-save" style="padding:5px; box-shadow:none;" onclick="prepararEdicion(${idActual}, ${filaString})">✎</button>
                            <button class="btn-cancel" style="padding:5px; box-shadow:none;" onclick="confirmarEliminar(${idActual})">🗑</button>
                        </div>
                    </td>
                </tr>
            `;
        }).join('');
    } catch (error) {
        console.error("Error al cargar tabla:", error);  
    }
}

async function guardar() {
    const token = localStorage.getItem('darwin_token');
    const config = configuracion[seccionActual];
    const datos = {};
    const tablaApi = obtenerNombreTablaAPI(seccionActual);

    config.campos.forEach(campo => {
        const input = document.getElementById(`input-${campo}`);
        if (input) {
            datos[campo.toUpperCase()] = input.value;
        }
    });

    const url = editandoId ? `${API_URL}/${tablaApi}/${editandoId}` : `${API_URL}/${tablaApi}`;
    const metodo = editandoId ? 'PUT' : 'POST';

    try {
        const response = await fetch(url, {
            method: metodo,
            headers: { 
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(datos)
        });

        if (response.ok) {
            mostrarNotificacion(editandoId ? "¡Actualizado con éxito!" : "¡Guardado con éxito!");
            limpiarForm();
            cargarDatosTabla(seccionActual);
        } else {
            const errorServer = await response.json();
            mostrarNotificacion("Error: " + (errorServer.error || "Fallo en servidor"), "error");
        }
    } catch (error) {
        mostrarNotificacion("Error de conexión", "error");
    }
}

async function ejecutarEliminar() {
    if (!idParaEliminar) return;
    const token = localStorage.getItem('darwin_token');
    const tablaApi = obtenerNombreTablaAPI(seccionActual);
    
    try {
        const response = await fetch(`${API_URL}/${tablaApi}/${idParaEliminar}`, { 
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${token}` }
        });
        if(response.ok) {
            cerrarModal();
            mostrarNotificacion("Eliminado correctamente");
            cargarDatosTabla(seccionActual);
        } else {
            mostrarNotificacion("No se pudo eliminar", "error");
        }
    } catch (error) {
        mostrarNotificacion("Error al eliminar", "error");
    }
}

// --- UTILIDADES ---

function prepararEdicion(id, datosFila) {
    editandoId = id;
    const config = configuracion[seccionActual];
    const btnSubmit = document.querySelector('button[onclick="guardar()"]');
    if(btnSubmit) btnSubmit.innerText = "Actualizar Registro";

    config.campos.forEach(campo => {
        const input = document.getElementById(`inpuat-${campo}`);
        if(input) {
            input.value = datosFila[campo.toUpperCase()] || datosFila[campo] || '';
        }
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function confirmarEliminar(id) {
    idParaEliminar = id;
    const modal = document.getElementById('modal-confirmacion');
    if(modal) modal.style.display = 'flex';
}

function cerrarModal() {
    const modal = document.getElementById('modal-confirmacion');
    if(modal) modal.style.display = 'none';
    idParaEliminar = null;
}

function filterTable() {
    const query = document.getElementById('global-search').value.toLowerCase();
    const rows = document.querySelectorAll('#tabla-body tr');
    rows.forEach(row => {
        // Esto busca en TODA la fila, incluyendo los nombres que trajimos con el JOIN
        row.style.display = row.innerText.toLowerCase().includes(query) ? '' : 'none';
    });
}
function obtenerNombreIdLocal(tabla) {
    const mapping = {
        'accion': 'ID_ACCION', 'accion_especifica': 'ID_AE', 'actividad': 'ID_ACTIVIDAD',
        'detalle_registro': 'ID_REGISTRO', 'subaccion': 'ID_SA', 'tipo_agente': 'ID_TA',
        'tipo_transporte': 'id_tt', 'zona_distrito': 'id_zd', 'zona_provincia': 'id_zp'
    };
    return mapping[tabla];
}

function obtenerNombreTablaAPI(seccion) {
    const map = {
        'registro': 'detalle_registro', 'ae': 'accion_especifica', 'agente': 'tipo_agente',
        'transporte': 'tipo_transporte', 'provincia': 'zona_provincia', 'distrito': 'zona_distrito'
    };
    return map[seccion] || seccion;
}

function limpiarForm() {
    editandoId = null;
    const btnSubmit = document.querySelector('button[onclick="guardar()"]');
    if(btnSubmit) btnSubmit.innerText = "Guardar Registro";
    const inputs = document.querySelectorAll('#form-dinamico input');
    inputs.forEach(i => i.value = "");
}

function mostrarNotificacion(mensaje, tipo = 'success') {
    const container = document.getElementById('toast-container');
    if(!container) return;
    const toast = document.createElement('div');
    toast.className = `toast ${tipo}`;
    toast.innerHTML = `<span>${mensaje}</span>`;
    container.appendChild(toast);
    setTimeout(() => {
        toast.style.animation = 'fadeOut 0.5s ease forwards';
        setTimeout(() => toast.remove(), 500);
    }, 3000);
}

// --- INICIALIZACIÓN ---

document.addEventListener('DOMContentLoaded', () => {
    const token = localStorage.getItem('darwin_token');
    const loginOverlay = document.getElementById('login-overlay');

    if (!token) {
        if(loginOverlay) loginOverlay.style.display = 'flex';
    } else {
        if(loginOverlay) loginOverlay.style.display = 'none';
        showSection('registro');
    }

    // Configurar botón modal borrado
    const btnConfirm = document.getElementById('btn-confirmar-borrado');
    if(btnConfirm) btnConfirm.onclick = ejecutarEliminar;
    
    if (typeof lucide !== 'undefined') lucide.createIcons();
});

async function llenarSelectsDeRegistro() {
    const token = localStorage.getItem('darwin_token');
    
    const mapeoTablas = {
        'id_accion': { tabla: 'accion', display: 'NOMBRE_ACCION', id: 'ID_ACCION' },
        'id_ae': { tabla: 'accion_especifica', display: 'ACCION_ESPECIFICA', id: 'ID_AE' },
        'id_sa': { tabla: 'subaccion', display: 'SUB_ACCION_ESP', id: 'ID_SA' }, // Agregado
        'id_ta': { tabla: 'tipo_agente', display: 'NOMBRE_TA', id: 'ID_TA' },
        'id_tt': { tabla: 'tipo_transporte', display: 'NOMBRE_TRANSPORTE', id: 'id_tt' },
        'id_zp': { tabla: 'zona_provincia', display: 'NOMBRE_PROVINCIA', id: 'id_zp' },
        'id_zd': { tabla: 'zona_distrito', display: 'NOMBRE_DISTRITO', id: 'id_zd' }, // Agregado
        'id_actividad': { tabla: 'actividad', display: 'NOMBRE_ACTIVIDAD', id: 'ID_ACTIVIDAD' } // Agregado
    };

    for (const [idInput, info] of Object.entries(mapeoTablas)) {
        const select = document.getElementById(`input-${idInput}`);
        if (!select) continue;

        try {
            const res = await fetch(`${API_URL}/${info.tabla}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const datos = await res.json();
            
            // Llenamos el select con los datos reales de la DB
            select.innerHTML = '<option value="">Seleccione...</option>' + 
                datos.map(d => `<option value="${d[info.id]}">${d[info.display]}</option>`).join('');
        } catch (error) {
            console.error("Error cargando select:", info.tabla);
        }
    }
}